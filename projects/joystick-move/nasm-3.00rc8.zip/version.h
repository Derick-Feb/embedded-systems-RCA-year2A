#ifndef NASM_VERSION_H
#define NASM_VERSION_H
#define NASM_MAJOR_VER      2
#define NASM_MINOR_VER      99
#define NASM_SUBMINOR_VER   99
#define NASM_PATCHLEVEL_VER 98
#define NASM_VERSION_ID     0x02636362
#define NASM_VER            "3.00rc8"
#endif /* NASM_VERSION_H */
